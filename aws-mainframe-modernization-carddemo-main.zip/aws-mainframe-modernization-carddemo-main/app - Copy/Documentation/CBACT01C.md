### High-Level Summary:
The program `CBACT01C` is a batch COBOL program that reads records from an account data file and prints the account details. It handles file operations such as opening, reading, and closing the file, and includes error handling for these operations.

### Paragraph Summaries:
1. **0000-MAINLINE**:
   - Initializes the program, opens the account file, reads and processes each record, and then closes the file.

2. **1000-ACCTFILE-GET-NEXT**:
   - Reads the next record from the account file and checks for the end of the file.

3. **1100-DISPLAY-ACCT-RECORD**:
   - Displays the details of the current account record.

4. **0000-ACCTFILE-OPEN**:
   - Opens the account file and checks for successful opening.

5. **9000-ACCTFILE-CLOSE**:
   - Closes the account file and checks for successful closing.

6. **9999-ABEND-PROGRAM**:
   - Abends (terminates) the program with an error message if an error occurs.

7. **9910-DISPLAY-IO-STATUS**:
   - Displays the I/O status in case of an error during file operations.